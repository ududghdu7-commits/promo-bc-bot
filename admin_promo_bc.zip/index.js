const { Client, GatewayIntentBits, EmbedBuilder, SlashCommandBuilder, REST, Routes, PermissionFlagsBits } = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent
    ]
});

const TOKEN = 'MTUzOTkxMTYzMzk5OTI0MTI4OQ.G1aZcf.NSkJ-sgn60s78PiN4XDKPjfOsOeVcU1MT1U3a4';
const CLIENT_ID = '1539911633999241289';
const TARGET_CHANNEL_ID = '1527636447757340812';

const pointsMap = new Map();
const cooldowns = new Set();
const allowedAdmins = new Set();

const commands = [
    new SlashCommandBuilder()
        .setName('points')
        .setDescription('عرض نقاطك أو نقاط إداري آخر')
        .addUserOption(opt => opt.setName('user').setDescription('الإداري المراد فحص نقاطه')),
    
    new SlashCommandBuilder()
        .setName('top')
        .setDescription('عرض قائمة متصدري التفاعل للإدارة'),

    new SlashCommandBuilder()
        .setName('addadmin')
        .setDescription('تحديد إداري لتفعيل احتساب النقاط له (للإدارة فقط)')
        .addUserOption(opt => opt.setName('user').setDescription('الإداري المراد إضافته').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName('removeadmin')
        .setDescription('إزالة إداري من نظام احتساب النقاط (للإدارة فقط)')
        .addUserOption(opt => opt.setName('user').setDescription('الإداري المراد إزالته').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName('addpoints')
        .setDescription('إضافة نقاط لإداري يدوياً (للإدارة فقط)')
        .addUserOption(opt => opt.setName('user').setDescription('الإداري').setRequired(true))
        .addIntegerOption(opt => opt.setName('amount').setDescription('عدد النقاط').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName('removepoints')
        .setDescription('خصم نقاط من إداري يدوياً (للإدارة فقط)')
        .addUserOption(opt => opt.setName('user').setDescription('الإداري').setRequired(true))
        .addIntegerOption(opt => opt.setName('amount').setDescription('عدد النقاط').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName('resetpoints')
        .setDescription('تصفير نقاط إداري أو الجميع (للإدارة فقط)')
        .addUserOption(opt => opt.setName('user').setDescription('تصفير إداري محدد (اتركه فارغاً لتصفير الكل)'))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName('bc')
        .setDescription('إرسال رسالة برودكاست للخاص لجميع أعضاء السيرفر (للإدارة فقط)')
        .addStringOption(opt => opt.setName('message').setDescription('نص الرسالة المراد إرسالها').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
].map(cmd => cmd.toJSON());

const rest = new REST({ version: '10' }).setToken(TOKEN);

client.once('ready', async () => {
    console.log(`🤖 تم تشغيل البوت بنجاح باسم: ${client.user.tag}`);
    try {
        const guilds = client.guilds.cache.map(g => g.id);
        for (const guildId of guilds) {
            await rest.put(Routes.applicationGuildCommands(CLIENT_ID, guildId), { body: commands });
        }
        console.log('✅ تم تسجيل وتحديث الأوامر بنجاح!');
    } catch (err) {
        console.error('❌ خطأ في تسجيل الأوامر:', err);
    }
});

// احتساب النقاط كل 30 دقيقة
client.on('messageCreate', message => {
    if (message.author.bot || !message.guild) return;
    if (message.channel.id !== TARGET_CHANNEL_ID) return;

    const userId = message.author.id;

    if (!allowedAdmins.has(userId)) return;
    if (cooldowns.has(userId)) return;

    const currentPoints = pointsMap.get(userId) || 0;
    pointsMap.set(userId, currentPoints + 1);

    cooldowns.add(userId);
    setTimeout(() => {
        cooldowns.delete(userId);
    }, 30 * 60 * 1000);
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const { commandName, options } = interaction;

    if (commandName === 'addadmin') {
        const user = options.getUser('user');
        allowedAdmins.add(user.id);
        await interaction.reply({ content: `✅ تم إضافة الإداري <@${user.id}> لنظام احتساب النقاط بنجاح.` });
    }

    if (commandName === 'removeadmin') {
        const user = options.getUser('user');
        allowedAdmins.delete(user.id);
        await interaction.reply({ content: `🗑️ تم إزالة الإداري <@${user.id}> من نظام احتساب النقاط.` });
    }

    if (commandName === 'points') {
        const targetUser = options.getUser('user') || interaction.user;
        const pts = pointsMap.get(targetUser.id) || 0;
        const isAllowed = allowedAdmins.has(targetUser.id) ? 'مفعل ✅' : 'غير مفعل ❌';
        
        const embed = new EmbedBuilder()
            .setTitle('📊 **نقاط التفاعل للإدارة**')
            .setDescription(`الإداري: ${targetUser}\n🏆 **إجمالي النقاط:** \`${pts}\` نقطة\n⚙️ **حالة النظام له:** ${isAllowed}`)
            .setColor('#3498db');

        await interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'top') {
        const sorted = Array.from(pointsMap.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10);
        
        if (sorted.length === 0) {
            return interaction.reply({ content: '❌ لا يوجد نقاط مسجلة حتى الآن.', ephemeral: true });
        }

        const list = sorted.map(([id, pts], index) => `**#${index + 1}** <@${id}> — \`${pts}\` نقطة`).join('\n');

        const embed = new EmbedBuilder()
            .setTitle('🏆 **قائمة المتصدرين للترقية**')
            .setDescription(list)
            .setColor('#f1c40f');

        await interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'addpoints') {
        const user = options.getUser('user');
        const amount = options.getInteger('amount');
        const current = pointsMap.get(user.id) || 0;
        
        pointsMap.set(user.id, current + amount);
        await interaction.reply({ content: `✅ تم إضافة \`${amount}\` نقطة للـ <@${user.id}>. النقاط الحالية: \`${current + amount}\`` });
    }

    if (commandName === 'removepoints') {
        const user = options.getUser('user');
        const amount = options.getInteger('amount');
        const current = pointsMap.get(user.id) || 0;
        const finalPts = Math.max(0, current - amount);

        pointsMap.set(user.id, finalPts);
        await interaction.reply({ content: `✅ تم خصم \`${amount}\` نقطة من <@${user.id}>. النقاط الحالية: \`${finalPts}\`` });
    }

    if (commandName === 'resetpoints') {
        const user = options.getUser('user');
        if (user) {
            pointsMap.set(user.id, 0);
            await interaction.reply({ content: `✅ تم تصفير نقاط الإداري <@${user.id}> بنجاح.` });
        } else {
            pointsMap.clear();
            await interaction.reply({ content: `⚠️ تم تصفير نقاط جميع الإداريين بنجاح.` });
        }
    }

    if (commandName === 'bc') {
        const messageContent = options.getString('message');
        await interaction.deferReply({ ephemeral: true });

        const members = await interaction.guild.members.fetch();
        let successCount = 0;
        let failCount = 0;

        for (const [id, member] of members) {
            if (member.user.bot) continue;

            try {
                const embed = new EmbedBuilder()
                    .setTitle(`📢 رسالة إدارية من ${interaction.guild.name}`)
                    .setDescription(messageContent)
                    .setColor('#e74c3c')
                    .setTimestamp();

                await member.send({ embeds: [embed] });
                successCount++;
            } catch (err) {
                failCount++;
            }
        }

        await interaction.editReply({
            content: `✅ تم الانتهاء من إرسال البرودكاست!\n📤 **تم الإرسال بنجاح إلى:** ${successCount} عضو.\n❌ **فشل الإرسال إلى:** ${failCount} عضو (بسبب إغلاق الخاص).`
        });
    }
});

client.login(TOKEN);
